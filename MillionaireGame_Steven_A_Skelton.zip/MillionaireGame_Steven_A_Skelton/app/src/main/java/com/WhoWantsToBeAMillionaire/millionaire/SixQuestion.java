package com.WhoWantsToBeAMillionaire.millionaire;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SixQuestion extends AppCompatActivity {

    // boolean for correct answer.
    public boolean correctAnswer = false;
    // boolean for checking if at least one answer has been selected
    boolean selectAnswer = false;
    // boolean for validating answer.
    boolean checkAnswer = false;

    // booleans for wrong answer disclosure
    boolean BratzDolls = false;
    boolean SylvanianFamilies = false;
    boolean Hatchimals = false;

    // boolean for AU info toast
    boolean infoAU = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.six_question);
    }

    public void onAnswerClick(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        RadioGroup rg_1 = (RadioGroup) findViewById(R.id.rg_1);
        RadioGroup rg_2 = (RadioGroup) findViewById(R.id.rg_2);

        // Check which checkbox was clicked
        switch (view.getId()) {
            case R.id.BratzDolls:
                if (checked) {
                    // Toast for displaying one time info abut AU
                    if (!infoAU) {
                        Toast.makeText(this, R.string.BratzDollsFeedback, Toast.LENGTH_LONG).show();
                        infoAU = true;
                    }
                    // Toast for final answer confirmation.
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    correctAnswer = false;
                    BratzDolls = false;
                    SylvanianFamilies = false;
                    Hatchimals = false;
                    rg_2.clearCheck();
                }
                break;
            case R.id.SylvanianFamilies:
                if (checked) {
                    // Toast for displaying one time info abut AU
                    if (!infoAU) {
                        Toast.makeText(this, R.string.BratzDollsFeedback, Toast.LENGTH_LONG).show();
                        infoAU = true;
                    }
                    // Toast for final answer confirmation.
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    BratzDolls = true;
                    correctAnswer = false;
                    SylvanianFamilies = false;
                    Hatchimals = false;
                    rg_2.clearCheck();
                }
                break;
            case R.id.Hatchimals:
                if (checked) {
                    // Toast for displaying one time info abut AU
                    if (!infoAU) {
                        Toast.makeText(this, R.string.BratzDollsFeedback, Toast.LENGTH_LONG).show();
                        infoAU = true;
                    }
                    // Toast for final answer confirmation.
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    SylvanianFamilies = true;
                    correctAnswer = false;
                    BratzDolls = false;
                    Hatchimals = false;
                    rg_1.clearCheck();
                }
                break;
            case R.id.Transformers:
                if (checked) {
                    // Toast for displaying one time info abut AU
                    if (!infoAU) {
                        Toast.makeText(this, R.string.BratzDollsFeedback, Toast.LENGTH_LONG).show();
                        infoAU = true;
                    }
                    // Toast for final answer confirmation.
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    Hatchimals = true;
                    correctAnswer = true;
                    BratzDolls = false;
                    SylvanianFamilies = false;
                    rg_1.clearCheck();
                }
                break;
        }
    }

    // Intent to move to the next question
    public void nextQuestion(View view) {

        if (selectAnswer) {
            if (checkAnswer) {
                Intent results = new Intent(this, SevenQuestion.class);
                startActivity(results);
            } else {
                checkAnswer = true;

                // Change the name of the button from validate to next question
                Button nextQuestion = findViewById(R.id.next_question);
                nextQuestion.setText(R.string.next_question);

                // Disable the buttons
                Button btnBratzDolls = (Button) findViewById(R.id.BratzDolls);
                btnBratzDolls.setEnabled(false);
                Button btnSylvanianFamilies = (Button) findViewById(R.id.SylvanianFamilies);
                btnSylvanianFamilies.setEnabled(false);
                Button btnHatchimals = (Button) findViewById(R.id.Hatchimals);
                btnHatchimals.setEnabled(false);
                Button btnTransformers = (Button) findViewById(R.id.Transformers);
                btnTransformers.setEnabled(false);

                // Add 1 to correctAnswers if the user answer is correct
                if (correctAnswer) {
                    MainActivity.correctAnswers++;

                    // Make background of correct answer to flash
                    btnTransformers.setBackground(getResources().getDrawable(R.drawable.a_valid_user_l_bg));
                    AnimationDrawable flashUserTransformers= (AnimationDrawable) btnTransformers.getBackground();
                    flashUserTransformers.start();

                    // Toast message to congratulate
                    Toast.makeText(this, R.string.CorrectAnswer, Toast.LENGTH_LONG).show();

                } else {
                    // Make background of correct answer to flash
                    btnTransformers.setBackground(getResources().getDrawable(R.drawable.a_valid_l_bg));
                    AnimationDrawable flashUserTransformers = (AnimationDrawable) btnTransformers.getBackground();
                    flashUserTransformers.start();

                    // Toast message for feedback
                    Toast.makeText(this, R.string.IncorrectAnswer, Toast.LENGTH_SHORT).show();

                // Feedback for wrong answer disclosure.
                } if (BratzDolls) {
                    Toast.makeText(this, R.string.SylvanianFamiliesFeedback, Toast.LENGTH_LONG).show();
                } if (SylvanianFamilies) {
                    Toast.makeText(this, R.string.HatchimalsFeedback, Toast.LENGTH_LONG).show();
                } if (Hatchimals) {
                    Toast.makeText(this, R.string.TransformersFeedback, Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this, R.string.SelectAnswer, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Prevents user to go to the previous question
     */
    @Override
    public void onBackPressed() {
    }

}
