package com.WhoWantsToBeAMillionaire.millionaire;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class EightQuestion extends AppCompatActivity {

    // booleans for correct answers.
    public boolean correctAnswer1 = false;
    public boolean correctAnswer2 = false;

    // boolean for checking if at least one answer has been selected
    boolean selectAnswer = false;
    // boolean for validating answer.
    boolean checkAnswer = false;

    // booleans for wrong answer disclosure
    boolean Ramadan = false;
    boolean Lent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.eight_question);
    }

    public void onAnswerClick(View view) {
        // Is the box now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch (view.getId()) {
            case R.id.Diwali:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    correctAnswer1 = true;
                } else {
                    correctAnswer1 = false;
                }
                break;
            case R.id.Lent:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    correctAnswer2 = true;
                } else {
                    correctAnswer2 = false;
                }
                break;
            case R.id.Ramadan:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    Ramadan = true;
                } else {
                    Ramadan = false;
                }
                break;
            case R.id.Hanukkah:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    Lent = true;
                } else {
                    Lent = false;
                }
                break;
        }
    }

    // Intent to move to the next question
    public void nextQuestion(View view) {

        if (selectAnswer) {
            if (checkAnswer) {
                Intent results = new Intent(this, NineQuestion.class);
                startActivity(results);
            } else {
                checkAnswer = true;

                // Change the name of the button from validate to next question
                Button nextQuestion = findViewById(R.id.next_question);
                nextQuestion.setText(R.string.next_question);

                // Disable the buttons
                Button btnDiwali = (Button) findViewById(R.id.Diwali);
                btnDiwali.setEnabled(false);
                Button btnHanukkah = (Button) findViewById(R.id.Hanukkah);
                btnHanukkah.setEnabled(false);
                Button btnRamadan = (Button) findViewById(R.id.Ramadan);
                btnRamadan.setEnabled(false);
                Button btnLent = (Button) findViewById(R.id.Lent);
                btnLent.setEnabled(false);

                // Make background of correct answers flash
                btnDiwali.setBackground(getResources().getDrawable(R.drawable.a_valid_l_bg));
                AnimationDrawable flashuserDiwali = (AnimationDrawable) btnDiwali.getBackground();


                // Add 1 to correctAnswers if all the user answers are correct
                if (correctAnswer1 && !Ramadan && !Lent) {
                    MainActivity.correctAnswers++;

                    // Make background of correct answer to flash 
                    flashuserDiwali.start();


                    // Toast message to congratulate
                    Toast.makeText(this, R.string.CorrectAnswers, Toast.LENGTH_LONG).show();

                } else {
                    // Make background of correct answer to flash
                    if (correctAnswer1) {
                        flashuserDiwali.start();
                    }

                    // Toast message for feedback
                    Toast.makeText(this, R.string.IncorrectAnswers, Toast.LENGTH_LONG).show();

                }
                // Feedback for wrong answer disclosure.
                if (Ramadan) {
                    Toast.makeText(this, R.string.RamadanFeedback, Toast.LENGTH_LONG).show();
                }
                if (Lent) {
                    Toast.makeText(this, R.string.LentFeedback, Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this, R.string.SelectAnswers, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Prevents user to go to the previous question
     */
    @Override
    public void onBackPressed() {
    }

}
