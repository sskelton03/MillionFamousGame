package com.WhoWantsToBeAMillionaire.millionaire;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SevenQuestion extends AppCompatActivity {

    // booleans for correct answers.
    public boolean correctAnswer1 = false;
    public boolean correctAnswer2 = false;
    public boolean correctAnswer3 = false;
    public boolean correctAnswer4 = false;

    // boolean for checking if there user gave input
    boolean inputAnswer = false;
    // boolean for validating answer.
    boolean checkAnswer = false;

    // variables storing the user input
    private EditText Angry;
    private EditText Chatty;
    private EditText Beautiful;
    private EditText Shy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.seven_question);

        //Initialize user text input
        Angry = (EditText) findViewById(R.id.Angry);
        Chatty = (EditText) findViewById(R.id.Chatty);
        Beautiful = (EditText) findViewById(R.id.Beautiful);
        Shy = (EditText) findViewById(R.id.Shy);
    }

    // Feedback for final answer
    public void onAnswerClick(View view) {
        Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
    }


    // Intent to move to the next question
    public void nextQuestion(View view) {

        // Give feedback for no input
        if (Chatty.length() == 0 ) {
            Toast.makeText(this, R.string.WriteAnswers, Toast.LENGTH_SHORT).show();

        } else if (checkAnswer) {
            // Move to next question
            Intent results = new Intent(this, EightQuestion.class);
            startActivity(results);

        } else {
            checkAnswer = true;

            // validate answers
            if (Angry.getText().toString().trim().equals(getString(R.string.Angry_a)))
                correctAnswer1 = false;
            if (Chatty.getText().toString().trim().equals(getString(R.string.Chatty_a)))
                correctAnswer2 = true;
            if (Beautiful.getText().toString().trim().equals(getString(R.string.Beautiful_a)))
                correctAnswer3 = false;
            if (Shy.getText().toString().trim().equals(getString(R.string.Shy_a)))
                correctAnswer4 = false;

            // Change the name of the button from validate to next question
            Button nextQuestion = findViewById(R.id.next_question);
            nextQuestion.setText(R.string.next_question);

            // Disable the buttons
            EditText textAngry = (EditText) findViewById(R.id.Angry);
            textAngry.setEnabled(false);
            EditText textChatty = (EditText) findViewById(R.id.Chatty);
            textChatty.setEnabled(false);
            EditText textBeautiful = (EditText) findViewById(R.id.Beautiful);
            textBeautiful.setEnabled(false);
            EditText textShy = (EditText) findViewById(R.id.Shy);
            textShy.setEnabled(false);

            // Make background of correct answers flash
            textChatty.setBackground(getResources().getDrawable(R.drawable.a_valid_user_l_bg));
            AnimationDrawable flashChatty = (AnimationDrawable) textChatty.getBackground();


            // Add 1 to correctAnswers if all user answers are correct
            if (correctAnswer2) {
                MainActivity.correctAnswers++;

                // Flash correct answers
                flashChatty.start();


                // Toast message to congratulate
                Toast.makeText(this, R.string.CorrectAnswers, Toast.LENGTH_LONG).show();

                // Validate individual answers (no points received)
            } else {

                // Toast message for feedback
                Toast.makeText(this, R.string.IncorrectAnswers, Toast.LENGTH_LONG).show();

                if (correctAnswer1) {
                    // Make background of correct answer to flash
                    flashChatty.start();
                } else {
                    // Feedback for wrong answer disclosure.
                    Toast.makeText(this, R.string.AngryFeedback, Toast.LENGTH_LONG).show();
                }
            }
        }

    }

    /**
     * Prevents user to go to the previous question
     */
    @Override
    public void onBackPressed() {
    }

}
