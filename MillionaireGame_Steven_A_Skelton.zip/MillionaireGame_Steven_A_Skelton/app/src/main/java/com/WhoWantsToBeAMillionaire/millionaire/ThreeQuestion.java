package com.WhoWantsToBeAMillionaire.millionaire;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class ThreeQuestion extends AppCompatActivity {

    // booleans for correct answers.
    public boolean correctAnswer1 = false;
    public boolean correctAnswer2 = false;

    // boolean for checking if at least one answer has been selected
    boolean selectAnswer = false;
    // boolean for validating answer.
    boolean checkAnswer = false;

    // booleans for wrong answer disclosure
    boolean Ana = false;
    boolean Bell = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.three_question);
    }

    public void onAnswerClick(View view) {
        // Is the box now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch (view.getId()) {
            case R.id.Elsa:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    correctAnswer1 = true;
                } else {
                    correctAnswer1 = false;
                }
                break;
            case R.id.Cinderella:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    correctAnswer2 = true;
                } else {
                    correctAnswer2 = false;
                }
                break;
            case R.id.Ana:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    Ana = true;
                } else {
                    Ana = false;
                }
                break;
            case R.id.Bell:
                if (checked) {
                    // Show validity of the answer as a toast
                    Toast.makeText(this, R.string.FinalAnswer, Toast.LENGTH_SHORT).show();
                    selectAnswer = true;
                    Bell = true;
                } else {
                    Bell = false;
                }
                break;
        }
    }

    // Intent to move to the next question
    public void nextQuestion(View view) {

        if (selectAnswer) {
            if (checkAnswer) {
                Intent results = new Intent(this, FourQuestion.class);
                startActivity(results);
            } else {
                checkAnswer = true;

                // Change the name of the button from validate to next question
                Button nextQuestion = findViewById(R.id.next_question);
                nextQuestion.setText(R.string.next_question);

                // Disable the buttons
                Button Elsa = (Button) findViewById(R.id.Elsa);
                Elsa.setEnabled(false);
                Button btnCinderella = (Button) findViewById(R.id.Cinderella);
                btnCinderella.setEnabled(false);
                Button btnAna = (Button) findViewById(R.id.Ana);
                btnAna.setEnabled(false);
                Button btnBell = (Button) findViewById(R.id.Bell);
                btnBell.setEnabled(false);

                // Make background of correct answers flash
                btnCinderella.setBackground(getResources().getDrawable(R.drawable.a_valid_l_bg));
                AnimationDrawable flashArgon = (AnimationDrawable) btnCinderella.getBackground();

                btnCinderella.setBackground(getResources().getDrawable(R.drawable.a_valid_r_bg));
                AnimationDrawable flashCarbonD = (AnimationDrawable) btnCinderella.getBackground();

                // Make background of user correct answers flash
                Elsa.setBackground(getResources().getDrawable(R.drawable.a_valid_user_l_bg));
                AnimationDrawable flashUserArgon = (AnimationDrawable) Elsa.getBackground();

                btnCinderella.setBackground(getResources().getDrawable(R.drawable.a_valid_user_r_bg));
                AnimationDrawable flashUserCarbonD = (AnimationDrawable) btnCinderella.getBackground();

                // Add 1 to correctAnswers if all the user answers are correct
                if (correctAnswer1 && correctAnswer2 && !Ana && !Bell) {
                    MainActivity.correctAnswers++;

                    // Make background of correct answer to flash
                    flashUserArgon.start();
                    flashUserCarbonD.start();

                    // Toast message to congratulate
                    Toast.makeText(this, R.string.CorrectAnswers, Toast.LENGTH_LONG).show();

                } else {
                    // Make background of correct answer to flash
                    if (correctAnswer1){
                        flashUserArgon.start();
                    } else {
                        flashArgon.start();
                    }
                    if (correctAnswer2){
                        flashUserCarbonD.start();
                    } else {
                        flashCarbonD.start();
                    }

                    // Toast message for feedback
                    Toast.makeText(this, R.string.IncorrectAnswers, Toast.LENGTH_LONG).show();

                // Feedback for wrong answer disclosure.
                } if (Ana) {
                    Toast.makeText(this, R.string.methaneFeedback, Toast.LENGTH_LONG).show();
                } if (Bell) {
                    Toast.makeText(this, R.string.ammoniaFeedback, Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this, R.string.SelectAnswers, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Prevents user to go to the previous question
     */
    @Override
    public void onBackPressed() {
    }

}
